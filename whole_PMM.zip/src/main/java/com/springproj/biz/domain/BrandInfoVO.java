package com.springproj.biz.domain;

import java.sql.Date;

import org.springframework.web.multipart.MultipartFile;

public class BrandInfoVO {	// javaBean
	private int bi_no;
	private int bi_bno;
	private String bi_biznum;
	private String bi_compname;
	private String bi_comptel;
	private String bi_repr;
	private String bi_compurnum;
	private String bi_addr;
	private String bi_desc;
	private String bi_bizlic;
	private String bi_shop;
	private String bi_snsin;
	private String bi_snski;
	private String bi_fax;
	private String bi_img;
	private Date bi_regidate;
}
